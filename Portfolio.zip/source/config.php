<?php
 session_start();

 define("FACEBOOK", [
  "app_id"=>"595497731171406",
  "app_secret"=>"e755bb5ad53261dd14e1ace1d62e71df",
  "app_redirect" =>"https://localhost/portfolio",
  "app_version"=>"v7.0"
]);
 ?>